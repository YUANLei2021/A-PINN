import torch
import numpy as np
import matplotlib.pyplot as plt
import datetime
import torch.nn as fun
import os


def main():
    #  pde parameters
    lam = [0.1, 0.1]
    x_range = [0.0, 1.0]
    t_range = [0.0, 1.0]
    pde_parameters = [lam, x_range, t_range]

    # train parameters
    ni = 100
    nb = 100
    nf = 1000  # 采样值个数
    optimizer = 0  # 0: L-BFGS 1: Adam 2: SGD
    max_iter = 1000  # 模型训练次数
    min_loss = 1e-8  # 当loss小于min值时停止
    learning_rate = 0.1  # 设置梯度下降中的学习率
    process = True  # 是否显示训练过程
    train_parameters = [ni, nb, nf, optimizer, max_iter, min_loss, learning_rate, process]

    # test parameters
    dx = 0.01
    dt = (t_range[1] - t_range[0]) / 100
    test_parameters = [dx, dt]

    # Neural networks parameters
    nn_layers = [2, 40, 40, 3]  # neural networks layers
    act_fun = 0  # 0: fun.Tanh(), 1: fun.Sigmoid(), 2: fun.ReLU(), 3: Sin()
    nn_parameters = [nn_layers, act_fun]

    dirs = ['./model', './data', './png']
    for dir in dirs:
        if not os.path.exists(dir):
            os.makedirs(dir)

    train(pde_parameters, train_parameters, nn_parameters)  # train nn model
    # test(pde_parameters, test_parameters)


class Net(torch.nn.Module):
    def __init__(self, parameters):
        [nn_layers, act_fun] = parameters
        af_list = {
            0: fun.Tanh(),
            1: fun.Sigmoid(),
            2: fun.ReLU(),
            3: Sin()
        }
        activation_function = af_list.get(act_fun, None)
        super(Net, self).__init__()
        self.layers = torch.nn.ModuleList()
        for i in range(len(nn_layers)-2):
            self.layers.append(torch.nn.Linear(nn_layers[i], nn_layers[i + 1]),)
            self.layers.append(activation_function)
        self.layers.append(torch.nn.Linear(nn_layers[-2], nn_layers[-1]),)

    def forward(self, x):
        for m in self.layers:
            x = m(x)
        return x


class Sin(torch.nn.Module):
    @staticmethod
    def forward(x):
        return torch.sin(x)


def pred(net_model, x, t, x_range, t_range):  # 先归一化 再预测值
    x_lb = x_range[0]
    x_ub = x_range[1]
    x_ = 2.0 * (x - x_lb) / (x_ub - x_lb) - 1.0
    t_lb = t_range[0]
    t_ub = t_range[1]
    t_ = 2.0 * (t - t_lb) / (t_ub - t_lb) - 1.0
    model_return = net_model(torch.cat((x_, t_), 1))
    u, v, w = torch.split(model_return, 1, dim=1)
    return u, v, w


def train(pde_parameters, train_parameters, nn_parameters):
    # loading parameters
    [ni, nb, nf, opt, max_iter, min_loss, learning_rate, process] = train_parameters
    [lam, x_range, t_range] = pde_parameters
    # choose device to train model
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    device = 'cpu'
    # x t input
    t_i = torch.FloatTensor(np.ones([ni, 1]) * t_range[0]).to(device)  # 初始t值
    x_i = torch.FloatTensor(np.linspace(x_range[0], x_range[1], ni, endpoint=True).reshape(-1, 1)).to(device)
    t_lb = torch.FloatTensor(np.linspace(t_range[0], t_range[1], nb, endpoint=True).reshape(-1, 1)).to(device)
    x_lb = torch.FloatTensor(np.ones([nb, 1]).reshape(-1, 1) * x_range[0]).to(device)  # 下边界

    x_exact = np.arange(x_range[0], x_range[1] + 1e-3, 1e-3)
    t_exact = np.arange(t_range[0], t_range[1] + 1e-3, 1e-3)
    x_e_mesh, t_e_mesh = np.meshgrid(x_exact, t_exact)  # 根据 x 和 t 生成网格
    t_e = t_e_mesh.flatten()
    x_e = x_e_mesh.flatten()
    idx = np.random.choice(x_e.shape[0], nf, replace=False)
    t_star = t_e[idx].reshape(-1, 1)
    t_f = torch.FloatTensor(t_star).to(device)
    x_star = x_e[idx].reshape(-1, 1)
    x_f = torch.FloatTensor(x_star).to(device)
    u_star = x_star + t_star * np.sin(t_star + x_star)
    noise = 0.00
    normal_data = np.random.normal(0, 1, u_star.shape)
    u_star = u_star * (1 + noise * normal_data)
    training_points = np.append(np.append(x_star, t_star, axis=1), u_star, axis=1)
    u_f = torch.FloatTensor(u_star).to(device)
    # dynamic display during training
    x_test = np.linspace(x_range[0], x_range[1], 100)
    t_test = np.linspace(t_range[0], t_range[1], 100)
    t_mesh, x_mesh = np.meshgrid(t_test, x_test)  # 根据 x 和 t 生成网格
    tx_shape = np.shape(x_mesh)  # 记录网格形状
    x_test_ts = torch.FloatTensor(x_mesh.flatten()[:, None]).to(device)  # 网格拍平
    t_test_ts = torch.FloatTensor(t_mesh.flatten()[:, None]).to(device)
    u_test = x_test_ts + t_test_ts * torch.sin(t_test_ts + x_test_ts)
    u_test = u_test.data.numpy().reshape(tx_shape)
    # loading initial condition
    # set x t require grad
    t_i.requires_grad = True
    t_lb.requires_grad = True
    x_lb.requires_grad = True
    t_f.requires_grad = True
    x_f.requires_grad = True
    # initialize neural networks and optimizer
    net_model = Net(nn_parameters).to(device)
    # add hyper-parameters to NN
    lam_f = torch.nn.Parameter(torch.FloatTensor(lam), requires_grad=True)
    net_model.register_parameter('lam', lam_f)
    # choose optimizer
    if opt == 1:
        optimizer = torch.optim.Adam([{'params': net_model.parameters()}], lr=learning_rate)  # 设置模型的优化算法 及学习率
    elif opt == 2:
        optimizer = torch.optim.SGD([{'params': net_model.parameters()}], lr=learning_rate)  # 设置模型的优化算法 及学习率
    else:
        optimizer = torch.optim.LBFGS([{'params': net_model.parameters()}], lr=learning_rate)  # 设置模型的优化算法 及学习率
    # set loss function
    loss_func = torch.nn.MSELoss().to(device)
    lam_record = np.empty([0, 2])
    # 空变量记录loss变化; 空画板展示预测值变化
    it = 0  # 循环次数
    loss = 10  # 初始化loss的值
    loss_record = np.empty([0, 3])
    plt.ion()  # 初始化动态图
    print('------------------------Neural networks------------------------------------')
    print(net_model)
    print('----------------------------Optimizer--------------------------------------')
    print(optimizer)
    print('------------------------Training device: ', device, '-----------------------------')
    #  -----------   开始训练   ------------
    starttime_train = datetime.datetime.now()  # 记录开始训练时间
    print('------------------------Start training:{}---------------------'.format(starttime_train))  # 输出模型开始训练

    while it < max_iter and loss > min_loss:
        def closure():
            u_i_pred, v_i_pred, w_i_pred = pred(net_model, x_i, t_i, x_range, t_range)
            u_lb_pred, v_lb_pred, w_lb_pred = pred(net_model, x_lb, t_lb, x_range, t_range)
            u_f_pred, v_f_pred, w_f_pred = pred(net_model, x_f, t_f, x_range, t_range)

            u_f_pred_dt = torch.autograd.grad(u_f_pred.sum(), t_f, create_graph=True)[0]
            u_f_pred_dtt = torch.autograd.grad(u_f_pred_dt.sum(), t_f, create_graph=True)[0]
            u_f_pred_dx = torch.autograd.grad(u_f_pred.sum(), x_f, create_graph=True)[0]

            v_f_pred_dx = torch.autograd.grad(v_f_pred.sum(), x_f, create_graph=True)[0]
            v_f_pred_dxt = torch.autograd.grad(v_f_pred_dx.sum(), t_f, create_graph=True)[0]
            w_f_pred_dt = torch.autograd.grad(w_f_pred.sum(), t_f, create_graph=True)[0]

            e_f = u_f_pred - u_f
            g_f = t_f * (-t_f ** 2 * torch.sin(t_f) ** 2 / 4 + torch.sin(t_f) + torch.sin(t_f) ** 2 / 8) + t_f *\
                  (x_f * torch.cos(x_f)- torch.sin(x_f) ** 2 / 8 - torch.sin(x_f)) - t_f * (-t_f ** 2 *
                  torch.sin(t_f - x_f) * torch.sin(t_f + x_f) / 4 + t_f * x_f * torch.sin(t_f - x_f) *
                   torch.sin(t_f + x_f) / 4 - t_f * x_f * torch.cos(t_f - x_f) * torch.cos(t_f + x_f) / 4 + x_f
                   * torch.sin(t_f - x_f) * torch.cos(t_f + x_f) / 8 + x_f * torch.sin(t_f + x_f) *
                   torch.cos(t_f - x_f) / 8 + x_f * torch.cos(t_f - x_f) + torch.sin(t_f - x_f) +
                   torch.sin(t_f - x_f) * torch.sin(t_f + x_f) / 8) + x_f + torch.sin(t_f + x_f) + 2 * torch.cos(t_f + x_f) - 1
            f = u_f_pred_dx - u_f_pred_dt - u_f_pred + g_f + lam_f[1] * v_f_pred - u_f_pred_dtt
            e_outputs1 = v_f_pred_dx - t_f * w_f_pred
            e_outputs2 = w_f_pred_dt - torch.cos(t_f - x_f) * u_f_pred
            loss_0 = loss_func(w_i_pred, torch.zeros_like(t_i))
            loss_b = loss_func(v_lb_pred, torch.zeros_like(t_lb))
            loss_f = loss_func(f, torch.zeros_like(t_f))
            loss_o = loss_func(e_outputs1, torch.zeros_like(t_f)) + loss_func(e_outputs2, torch.zeros_like(t_f))
            loss_u_f = loss_func(e_f, torch.zeros_like(x_f))
            loss_all = np.array((loss_0.data.numpy(), loss_b.data.numpy(), loss_f.data.numpy(), loss_o.data.numpy()))
            print(loss_all)
            loss_min = np.min(loss_all)
            loss_all = loss_all / loss_min

            loss_all[loss_all > 10] = 10.0
            loss_weight = loss_all
            # loss_weight = [1.0, 1.0, 1.0, 1.0]
            loss_total = 1.0 * loss_u_f + loss_weight[0] * loss_0 + loss_weight[1] * loss_b + loss_weight[2] * loss_f + loss_weight[3] * loss_o

            optimizer.zero_grad()  # 清空梯度
            loss_total.backward(retain_graph=True)
            return loss_total

        optimizer.step(closure)  # 运用梯度
        loss_value = closure().cpu().data.numpy()
        step_time = datetime.datetime.now() - starttime_train
        loss_record = np.append(loss_record, [[it, step_time.seconds + step_time.microseconds / 1000000, loss_value]],
                                axis=0)  # 记录损失值
        lam_record = np.append(lam_record, lam_f.data.numpy().reshape(1, 2), axis=0)
        if it % 10 == 0:
            print('Running: ', it, ' / ', max_iter)
            print(lam_f.data.data.numpy())
            if process:  # 是否显示迭代过程
                plt.clf()
                u_test_pred, _, _ = pred(net_model, x_test_ts, t_test_ts, x_range, t_range)
                u_test_pred = u_test_pred.data.numpy().reshape(tx_shape)
                plt.subplot(2, 1, 1)
                pic = plt.imshow(u_test_pred, cmap='jet', vmin=-1.0, vmax=1.0,
                                 extent=[t_range[0], t_range[1], x_range[0], x_range[1]],
                                 interpolation='nearest', origin='lower', aspect='auto')  # 画热点图
                plt.colorbar(pic)  # 加图例
                plt.scatter(t_star, x_star, label='Collocation points', s=1.0, c='k', marker='.')
                plt.xlim(t_range[0], t_range[1])
                plt.ylim(x_range[0], x_range[1])
                plt.legend(loc='upper right')
                plt.subplot(2, 1, 2)
                pic = plt.imshow(u_test, cmap='jet', vmin=-1.0, vmax=1.0,
                                 extent=[t_range[0], t_range[1], x_range[0], x_range[1]],
                                 interpolation='nearest', origin='lower', aspect='auto')  # 画热点图
                plt.colorbar(pic)  # 加图例
                plt.pause(0.1)  # 停留0.1秒
        it = it + 1
    endtime_train = datetime.datetime.now()  # 记录训练结束时间
    print('---------------End training:{}---------------'.format(endtime_train))  # 输出训练结束
    torch.save(net_model, './model/A-PINN_D_VIDE_2D.pkl')  # 保存整个网络
    np.savetxt('./data/A-PINN_D_VIDE_2D-loss.txt', loss_record)  # 保存loss数据
    np.savetxt('./data/A-PINN-D—2DVIDE-lam.txt', lam_record)  # 保存lam数据
    np.savetxt('./data/training points.txt', training_points)
    train_time = endtime_train - starttime_train  # 计算训练所用时间
    print('---------------Training time:{}s---------------'.format(train_time.seconds + train_time.microseconds / 1e6))

    plt.ioff()  # 更新图
    plt.show()

    plt.figure()  # 新建一张图画loss值变化
    plt.plot(loss_record[:, 0], np.log(loss_record[:, 2]))  # 画loss与iteration的变化图
    plt.savefig('./png/A-PINN_D_VIDE_2D-loss.png')
    plt.show()


def test(pde_parameters, test_parameters):

    x_exact = np.arange(0, 1 + 0.01, 0.01)
    t_exact = np.arange(0, 1 + 1e-4, 1e-4)
    t_test = t_exact.flatten()  # np.linspace(0, total_time, int(total_time / dt))
    x_test = x_exact.flatten()  # np.linspace(-1.0, 1, int(1 / dx))

    [_, x_range, t_range] = pde_parameters
    [dx, dt] = test_parameters
    net_model = torch.load('./model/A-PINN_VIDE.pkl')
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    device = 'cpu'
    # x_test = np.linspace(x_range[0], x_range[1], int(1 / dx))
    # t_test = np.linspace(t_range[0], t_range[1], int((t_range[1]-t_range[0]) / dt))

    x_mesh, t_mesh = np.meshgrid(x_test, t_test)  # 根据 x 和 t 生成网格
    xt_shape = np.shape(x_mesh)  # 记录网格形状
    t_test_ts = torch.FloatTensor(t_mesh.flatten()[:, None]).to(device)  # 网格拍平
    x_test_ts = torch.FloatTensor(x_mesh.flatten()[:, None]).to(device)  # 网格拍平
    u_test = x_test_ts + t_test_ts * torch.sin(t_test_ts + x_test_ts)
    u_exact = u_test.data.numpy().reshape(xt_shape).T
    plt.figure()
    u_test_pred, _ = pred(net_model, x_test_ts, t_test_ts, x_range, t_range)
    u_test_pred = u_test_pred.data.numpy().reshape(xt_shape).T
    u_t0 = u_test_pred[:, 0]
    u_tmid = u_test_pred[:, int(t_test.shape[0]/2)]
    u_tend = u_test_pred[:, -1]
    plt.subplot(2, 2, 1)
    pic = plt.imshow(u_test_pred, cmap='jet', vmin=-1.0, vmax=1.0,
                     extent=[t_range[0], t_range[1], x_range[0], x_range[1]],
                     interpolation='nearest', origin='lower', aspect='auto')  # 画热点图
    plt.colorbar(pic)  # 加图例
    plt.subplot(2, 2, 2)
    plt.plot(x_test, u_t0, label='t=' + str(round(t_range[0], 2)))
    plt.legend(loc='upper right')
    plt.subplot(2, 2, 3)
    plt.plot(x_test, u_tmid, label='t=' + str(round((t_range[1]-t_range[0])/2 + t_range[0], 2)))
    plt.legend(loc='upper right')
    plt.subplot(2, 2, 4)
    plt.plot(x_test, u_tend, label='t=' + str(round(t_range[1], 2)))
    plt.legend(loc='upper right')
    plt.tight_layout()
    plt.savefig('./png/A-PINN_VIDE-Pred.png')
    plt.show()

    l2error = np.linalg.norm(u_test_pred - u_exact, 2) / np.linalg.norm(u_exact, 2)
    abs_e = u_test_pred - u_exact
    print('L2 error: ', l2error)
    plt.subplot(3, 1, 1)
    pic = plt.imshow(u_test_pred, cmap='jet', vmin=0.0, vmax=1.0,
                     extent=[t_range[0], t_range[1], x_range[0], x_range[1]],
                     interpolation='nearest', origin='lower', aspect='auto')  # 画热点图
    plt.colorbar(pic)  # 加图例
    plt.subplot(3, 1, 2)
    pic = plt.imshow(u_exact, cmap='jet', vmin=0.0, vmax=1.0,
                     extent=[t_range[0], t_range[1], x_range[0], x_range[1]],
                     interpolation='nearest', origin='lower', aspect='auto')  # 画热点图
    plt.colorbar(pic)  # 加图例
    plt.subplot(3, 1, 3)
    pic = plt.imshow(abs_e, cmap='jet', vmin=-0.5, vmax=0.5,
                     extent=[t_range[0], t_range[1], x_range[0], x_range[1]],
                     interpolation='nearest', origin='lower', aspect='auto')  # 画热点图
    plt.colorbar(pic)  # 加图例
    plt.tight_layout()
    plt.savefig('./png/A-PINN_VIDE-Pred-Exact.png')
    plt.show()
    plt.figure(figsize=(8, 3))
    pic = plt.imshow(u_test_pred, cmap='jet', vmin=0.0, vmax=1.0,
                     extent=[t_range[0], t_range[1], x_range[0], x_range[1]],
                     interpolation='nearest', origin='lower', aspect='auto')  # 画热点图
    plt.colorbar(pic)  # 加图例
    plt.xlabel('t')
    plt.ylabel('x')
    plt.title('u(t,x)')
    plt.tight_layout()
    plt.savefig('./png/A-PINN_VIDE-u(x,t).png')
    plt.show()
    plt.figure(figsize=(8, 3))
    pic = plt.imshow(abs_e, cmap='jet', vmin=-0.1, vmax=0.1,
                     extent=[t_range[0], t_range[1], x_range[0], x_range[1]],
                     interpolation='nearest', origin='lower', aspect='auto')  # 画热点图
    plt.colorbar(pic)  # 加图例
    plt.xlabel('t')
    plt.ylabel('x')
    plt.title('Error in u(t,x)')
    plt.tight_layout()
    plt.savefig('./png/A-PINN_VIDE-abs(error).png')
    plt.show()


if __name__ == '__main__':
    main()
    pass
